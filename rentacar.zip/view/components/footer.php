<footer>
    <ul>
        <li><p><?=$l_arr["global"]["txt_6"];?></p></li>
        <li><a href="#"><?=$l_arr["global"]["txt_7"];?></a></li>
        <li><a href="#"><?=$l_arr["global"]["txt_8"];?></a></li>
        <li><a href="#"><?=$l_arr["global"]["txt_9"];?></a></li>
    </ul>
    <ul>
        <li><p><?=$l_arr["global"]["txt_10"];?></p></li>
        <li><a href="#"><?=$l_arr["global"]["txt_11"];?></a></li>
        <li><a href="#">Facebook</a></li>
        <li><a href="#">Whatsapp</a></li>
    </ul>
    <ul>
        <li><p><?=$l_arr["global"]["txt_12"];?></p></li>
        <li><a href="#"><?=$l_arr["global"]["txt_13"];?></a></li>
        <li><a href="#"><?=$l_arr["global"]["txt_14"];?></a></li>
        <li><a href="#"><?=$l_arr["global"]["txt_15"];?></a></li>
    </ul>
    <p>© <?=$l_arr["global"]["app_name"];?> 2021</p>
</footer>