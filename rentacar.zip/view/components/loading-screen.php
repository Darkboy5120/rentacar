<div class="loading-screen" id="loading-screen">
    <img src="media/images/bg_anim.gif" alt="">
    <p></p>
</div>